#ifndef UXU_H 
#define UXU_H
#define e extern
#define main kernel_main
inline void Xu(const char* m){
	char* c=(char*)0xb800;
	for(int x=0;m[x]!='\0';x++){
		c[x*2]=m[x];
		c[x*2+1]=0x0F;
	}
	while(true){
	}
}
#endif
