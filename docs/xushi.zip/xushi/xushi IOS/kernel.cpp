#include "UXU.h"
e "C" void main(){
	Xu("xushi IOS");
}
