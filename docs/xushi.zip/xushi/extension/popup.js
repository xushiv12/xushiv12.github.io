document.addEventListener('DOMContentLoaded', () => {
    refreshNews();
});

function refreshNews() {
    const newsContainer = document.getElementById('news-container');
    newsContainer.innerHTML = '';

    // 示例：随机生成一些新闻条目
    const sampleNews = [
        {
            title: '最新头条：Xushi新闻更新',
            summary: 'Xushi新闻扩展程序现在可以使用了！'
        },
        {
            title: '国际新闻：世界科技大会',
            summary: '来自全球的科技领袖齐聚一堂，共商未来。'
        },
        {
            title: '本地新闻：社区公益活动',
            summary: '社区成员积极参与，贡献社会力量。'
        }
    ];

    sampleNews.forEach(news => {
        const newsItem = document.createElement('div');
        newsItem.className = 'news-item';
        newsItem.innerHTML = `<strong>${news.title}</strong><p>${news.summary}</p>`;
        newsContainer.appendChild(newsItem);
    });
}