import socket
	
import json
    
server_socket=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    
server_socket.bind(("localhost",7890))
    
server_socket.listen(1)
	
print("http://localhost:7890")
	
while True:
	
 client_socket,_=server_socket.accept()
	
 x=client_socket.recv(1024).decode()
	
 y = x.split(" ")[1] if x and " " in x else "/"
	
 if y=="/":
	
    n="服务器"
	
 elif y=="/a":
	
    n="服务器a"
	
 elif y=="/b":
	
    n="服务器b"
	
 elif y=="/c":
	
    n="服务器c"
	
 elif y=="/d":
	
    n="服务器d"
	
 elif y=="/e":
	
    n="服务器e"
	
 else:
	
    n="404 服务器 not find."
	
 xu = "HTTP/1.1 200 OK\r\nContent-Type: text/plain\r\n\r\n" + n
	
 client_socket.sendall(xu.encode())
	
 client_socket.close()